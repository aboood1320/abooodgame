/* ==========================================================================
   أونو — تخلّص من بطاقاتك أولًا (نسخة رقمية محلية كاملة)
   ========================================================================== */
(function () {
  "use strict";

  const BG = window.BG;
  const U = BG.util;
  const FX = BG.fx;
  const AI = BG.ai;

  const COLORS = {
    red: { name: "أحمر", hex: "#d95356" },
    yellow: { name: "أصفر", hex: "#e3ae38" },
    green: { name: "أخضر", hex: "#4aa87b" },
    blue: { name: "أزرق", hex: "#4d83c4" },
  };
  const COLOR_KEYS = ["red", "yellow", "green", "blue"];
  const PCOLORS = ["#ef8074", "#5fa8f5", "#f2c75c", "#69cd8d", "#b98cd9", "#f0a35e"];

  /* ------------------------------ البطاقات ------------------------------ */

  function buildDeck() {
    const deck = [];
    let serial = 0;
    COLOR_KEYS.forEach((color) => {
      const add = (type, value, count) => {
        for (let i = 0; i < count; i++) {
          deck.push({ id: color + "-" + type + "-" + (value == null ? "x" : value) + "-" + serial++, color, type, value: value == null ? null : value });
        }
      };
      add("number", 0, 1);
      for (let value = 1; value <= 9; value++) add("number", value, 2);
      add("skip", null, 2);
      add("reverse", null, 2);
      add("draw2", null, 2);
    });
    for (let i = 0; i < 4; i++) deck.push({ id: "wild-0-" + serial++, color: "wild", type: "wild", value: null });
    for (let i = 0; i < 4; i++) deck.push({ id: "wild4-0-" + serial++, color: "wild", type: "wild4", value: null });
    return deck;
  }

  function cardLabel(card) {
    if (!card) return "";
    const color = COLORS[card.color] ? COLORS[card.color].name : "";
    if (card.type === "number") return color + " " + card.value;
    if (card.type === "skip") return color + " تخطٍّ";
    if (card.type === "reverse") return color + " عكس";
    if (card.type === "draw2") return color + " +2";
    if (card.type === "wild") return "بطاقة برّية";
    return "بطاقة برّية +4";
  }

  function cardPoints(card) {
    if (card.type === "number") return card.value;
    if (card.type === "wild" || card.type === "wild4") return 50;
    return 20;
  }

  function cardFace(card) {
    if (card.type === "number") return String(card.value);
    if (card.type === "skip") return "⊘";
    if (card.type === "reverse") return "⇄";
    if (card.type === "draw2") return "+2";
    if (card.type === "wild") return "★";
    return "+4";
  }

  /* ------------------------------ الحالة ------------------------------ */

  let rootRef = null;
  let apiRef = null;
  let state = null;
  let aiRunner = null;

  function cur() {
    return state.players[state.current];
  }

  function isOnline() {
    return !!(apiRef && apiRef.net && apiRef.net.enabled);
  }

  function unoOption(key) {
    const opts = (apiRef && apiRef.options) || {};
    const defaults = { drawUntilPlayable: false, stackDraw: false, challengeWild4: true, matchTo500: true };
    if (Object.prototype.hasOwnProperty.call(opts, key)) return !!opts[key];
    return !!defaults[key];
  }


  /** المقعد الذي يجلس عليه هذا الجهاز (أو -1 للمشاهد). */
  function viewerIndex() {
    if (isOnline()) return Number.isInteger(apiRef.net.seat) ? apiRef.net.seat : -1;
    return state ? state.current : -1;
  }

  function viewerPlayer() {
    const index = viewerIndex();
    return state && index >= 0 && state.players[index] ? state.players[index] : null;
  }

  /** هل يحق لهذا الجهاز رؤية يد اللاعب النشط الآن؟ */
  function canSeeActiveHand() {
    return !isOnline() || viewerIndex() === state.current;
  }

  function topCard() {
    return state.discard[state.discard.length - 1] || null;
  }

  function nextIndex(step) {
    const n = state.players.length;
    const offset = (state.dir * (step || 1)) % n;
    return ((state.current + offset) % n + n) % n;
  }

  function nextFrom(index, step) {
    const n = state.players.length;
    const offset = (state.dir * (step || 1)) % n;
    return ((index + offset) % n + n) % n;
  }

  function matches(card) {
    const top = topCard();
    if (!top) return true;
    if (card.color === "wild") return true;
    if (card.color === state.color) return true;
    if (card.type === "number") return top.type === "number" && card.value === top.value;
    if (card.type === "skip" || card.type === "reverse" || card.type === "draw2") return top.type === card.type;
    return false;
  }

  function isPlayable(card, playerIndex) {
    if (!state || state.over) return false;
    if (playerIndex !== state.current) return false;
    if (state.phase !== "play" && state.phase !== "drawn") return false;
    if (state.phase === "drawn" && card.id !== state.drawnCard) return false;
    if (state.pendingDraw > 0) {
      const top = topCard();
      if (card.type === "draw2" && top && top.type === "draw2") return true;
      if (card.type === "wild4" && top && (top.type === "wild4" || top.type === "draw2")) return true;
      return false;
    }
    return matches(card);
  }

  function sortHand(hand) {
    const order = { red: 0, yellow: 1, green: 2, blue: 3, wild: 4 };
    const typeOrder = { number: 0, skip: 1, reverse: 2, draw2: 3, wild: 4, wild4: 5 };
    return hand.slice().sort((a, b) => {
      if (order[a.color] !== order[b.color]) return order[a.color] - order[b.color];
      if (typeOrder[a.type] !== typeOrder[b.type]) return typeOrder[a.type] - typeOrder[b.type];
      return (a.value || 0) - (b.value || 0);
    });
  }

  /* ------------------------------ السحب ------------------------------ */

  function refillDeck() {
    if (state.deck.length) return true;
    if (state.discard.length <= 1) return false;
    const top = state.discard.pop();
    state.deck = U.shuffle(state.discard);
    state.discard = [top];
    if (FX) FX.sound("shuffle");
    if (apiRef) apiRef.log("نفدت كومة السحب، فأُعيد خلط البطاقات المكشوفة مع الاحتفاظ بالبطاقة العليا.", "");
    return true;
  }

  function drawInto(playerIndex, count) {
    let got = 0;
    for (let i = 0; i < count; i++) {
      if (!state.deck.length && !refillDeck()) break;
      state.players[playerIndex].hand.push(state.deck.shift());
      got += 1;
    }
    return got;
  }

  function drawPhrase(count) {
    if (count === 0) return "لم يسحب أي بطاقة";
    if (count === 1) return "سحب بطاقة واحدة";
    if (count === 2) return "سحب بطاقتين";
    return "سحب " + count + " بطاقات";
  }

  function setTurnNotice(extra) {
    const player = cur();
    state.notice =
      (extra ? extra + ". " : "") +
      (state.pendingDraw > 0
        ? "دور " + player.name + " — عليه سحب " + state.pendingDraw + " بطاقات: كدّس +2/+4 مماثلة أو اسحب العقوبة."
        : "دور " + player.name + " — أظهر يدك ثم العب بطاقة مطابقة أو اسحب بطاقة.");
    if (apiRef) apiRef.setStatus("دور " + AI.statusName(player));
  }

  /* ------------------------------ سير الدور ------------------------------ */

  function playCard(card, chosenColor) {
    if (!state || state.over) return false;
    const player = cur();
    const actual = player.hand.find((item) => item.id === card.id);
    if (!actual || !isPlayable(actual, state.current)) return false;

    player.hand = player.hand.filter((item) => item.id !== actual.id);
    state.discard.push(actual);
    state.lastCard = actual;
    state.drawnCard = null;

    const previousColor = state.color;
    let color = actual.color;
    if (actual.type === "wild" || actual.type === "wild4") {
      color = COLORS[chosenColor] ? chosenColor : U.pick(COLOR_KEYS);
    }
    state.color = color;

    if (apiRef) {
      apiRef.log(
        "<strong>" + U.escape(player.name) + "</strong> لعب " + U.escape(cardLabel(actual)) +
        ((actual.type === "wild" || actual.type === "wild4") ? " واختار اللون " + U.escape(COLORS[color].name) : "") + ".",
        "accent"
      );
    }
    if (FX) FX.sound("card");

    if (player.hand.length === 0) {
      endGame(state.current);
      return true;
    }

    if (player.hand.length === 1) {
      if (apiRef) apiRef.log("<strong>" + U.escape(player.name) + "</strong> أعلن «أونو!» — بقيت بطاقة واحدة.", "good");
      BG.toast("أونو! بقيت بطاقة واحدة لـ" + player.name, "good");
      if (FX) FX.sound("point");
    }

    let skip = false;
    let keepPending = false;
    let effect = "";

    if (actual.type === "reverse") {
      if (state.players.length === 2) {
        skip = true;
        effect = "عكس الاتجاه مع لاعبين — يعود الدور إلى " + player.name;
      } else {
        state.dir *= -1;
        effect = "انعكس اتجاه اللعب";
      }
    } else if (actual.type === "skip") {
      const target = nextIndex(1);
      skip = true;
      effect = "تخطّى دور " + state.players[target].name;
    } else if (actual.type === "draw2" || actual.type === "wild4") {
      const count = actual.type === "draw2" ? 2 : 4;
      const target = nextIndex(1);
      if (actual.type === "wild4" && unoOption("challengeWild4") && !unoOption("stackDraw")) {
        state.challenge = {
          offender: state.current,
          target,
          previousColor,
        };
        state.current = target;
        state.turn += 1;
        state.phase = "challenge";
        state.handRevealed = !BG.prefs.hideSecrets || isOnline();
        state.pendingDraw = 0;
        state.notice = "لعب " + player.name + " بطاقة +4. على " + state.players[target].name +
          " أن يتحدى البطاقة أو يقبل سحب أربع بطاقات.";
        if (apiRef) {
          apiRef.log("<strong>" + U.escape(player.name) + "</strong> لعب +4. القرار الآن لـ<strong>" +
            U.escape(state.players[target].name) + "</strong>: تحدٍّ أم سحب؟", "accent");
        }
        render();
        return true;
      }
      if (unoOption("stackDraw")) {
        state.pendingDraw = (state.pendingDraw || 0) + count;
        keepPending = true;
        effect = state.players[target].name + " " + state.pendingDraw + " بطاقات متراكمة (العقوبة تتزايد)";
      } else {
        const got = drawInto(target, count);
        skip = true;
        effect = state.players[target].name + " " + drawPhrase(got) + " وفقد دوره";
      }
    }

    if (effect && apiRef) apiRef.log(U.escape(effect) + ".", actual.type === "wild" || actual.type === "wild4" ? "accent" : "");

    state.current = nextIndex(skip ? 2 : 1);
    state.turn += 1;
    state.phase = "play";
    state.handRevealed = !BG.prefs.hideSecrets || isOnline();
    if (!keepPending) state.pendingDraw = 0;
    setTurnNotice(effect);
    render();

    if (FX) {
      FX.after(() => {
        const discard = rootRef && rootRef.querySelector(".uno-card.is-discard");
        if (discard) { FX.pop(discard); FX.pulse(discard); }
        const active = rootRef && rootRef.querySelector(".uno-player.active");
        if (active) FX.pulse(active);
      }, 30);
    }
    return true;
  }

  /** تحدي بطاقة +4: النجاح يعاقب صاحب البطاقة، والفشل يكلّف المتحدّي 6 بطاقات. */
  function resolveChallenge(accept) {
    if (!state || state.over || state.phase !== "challenge" || !state.challenge) return;
    const challenge = state.challenge;
    const offender = state.players[challenge.offender];
    const target = state.players[challenge.target];
    if (!offender || !target) { state.challenge = null; state.phase = "play"; return; }
    const guilty = offender.hand.some((card) => card.color === challenge.previousColor);
    state.challenge = null;
    let effect = "";

    if (!accept) {
      const got = drawInto(challenge.target, 6);
      state.current = nextFrom(challenge.target, 1);
      effect = target.name + " قبل +4 وسحب " + drawPhrase(got) + " (العقوبة الكاملة) وفقد دوره";
      if (apiRef) apiRef.log("قبل <strong>" + U.escape(target.name) + "</strong> بطاقة +4 وسحب " + got + " بطاقات.", "");
    } else if (guilty) {
      const got = drawInto(challenge.offender, 4);
      state.current = challenge.target;
      effect = "نجح التحدي — " + offender.name + " كان يملك لونًا مطابقًا، فسحب " + drawPhrase(got) + ". دور " + target.name;
      if (apiRef) {
        apiRef.log("🎯 <strong>" + U.escape(target.name) + "</strong> تحدّى +4 بنجاح! كان لدى <strong>" +
          U.escape(offender.name) + "</strong> لون مطابق، فسحب " + got + " بطاقات.", "good");
      }
      if (FX) FX.sound("point");
    } else {
      const got = drawInto(challenge.target, 6);
      state.current = nextFrom(challenge.target, 1);
      effect = "فشل التحدي — " + target.name + " سحب " + drawPhrase(got) + " وفقد دوره";
      if (apiRef) {
        apiRef.log("❌ فشل تحدّي <strong>" + U.escape(target.name) + "</strong> — لم يكن لدى <strong>" +
          U.escape(offender.name) + "</strong> لون مطابق، فسحب " + got + " بطاقات.", "warn");
      }
      if (FX) FX.sound("error");
    }

    state.phase = "play";
    state.turn += 1;
    state.handRevealed = !BG.prefs.hideSecrets || isOnline();
    state.pendingDraw = 0;
    setTurnNotice(effect);
    render();
  }

  function drawCard() {
    if (!state || state.over || state.phase !== "play") return;
    if (state.pendingDraw > 0) {
      const n = state.pendingDraw;
      state.pendingDraw = 0;
      drawInto(state.current, n);
      state.current = nextIndex(1);
      state.turn += 1;
      state.phase = "play";
      state.drawnCard = null;
      state.handRevealed = !BG.prefs.hideSecrets || isOnline();
      setTurnNotice("");
      render();
      if (FX) FX.sound("card");
      return;
    }
    if (!state.handRevealed && !AI.isCpu(cur())) {
      BG.toast("أظهر يدك أولًا لتعرف ما لديك قبل السحب.", "warn");
      if (FX) FX.sound("error");
      return;
    }
    if (!state.deck.length && !refillDeck()) {
      state.phase = "drawn";
      state.drawnCard = null;
      state.notice = "لا توجد بطاقات متاحة للسحب. يمكنك إنهاء الدور.";
      if (FX) FX.sound("error");
      render();
      return;
    }
    let drawnCount = 0;
    let lastCard = null;
    let playable = false;
    do {
      if (!state.deck.length && !refillDeck()) break;
      const c = state.deck.shift();
      cur().hand.push(c);
      drawnCount += 1;
      lastCard = c;
      playable = matches(c);
    } while (unoOption("drawUntilPlayable") && !playable && state.deck.length);

    state.phase = "drawn";
    state.drawnCard = (playable && lastCard) ? lastCard.id : null;

    const player = cur();
    if (apiRef) apiRef.log("<strong>" + U.escape(player.name) + "</strong> سحب بطاقة من كومة السحب.", "");
    state.notice = playable
      ? "سحبت بطاقة قابلة للعب. يمكنك لعبها الآن أو إنهاء الدور."
      : "سحبت بطاقة غير مطابقة. يمكنك إنهاء الدور.";
    if (FX) {
      FX.sound("card");
      FX.after(() => {
        if (!rootRef) return;
        const pile = rootRef.querySelector(".uno-card-back");
        if (pile) FX.pulse(pile);
        const hand = rootRef.querySelector(".uno-hand");
        if (hand) FX.pulse(hand);
      }, 30);
    }
    render();
  }

  function passTurn() {
    if (!state || state.over || state.phase !== "drawn") return;
    const player = cur();
    if (apiRef) apiRef.log("<strong>" + U.escape(player.name) + "</strong> أنهى دوره بعد السحب.", "");
    if (FX) FX.sound("pass");
    state.current = nextIndex(1);
    state.turn += 1;
    state.phase = "play";
    state.drawnCard = null;
    state.handRevealed = !BG.prefs.hideSecrets || isOnline();
    state.pendingDraw = 0;
    setTurnNotice("");
    render();
    if (FX) {
      FX.after(() => {
        const active = rootRef && rootRef.querySelector(".uno-player.active");
        if (active) FX.pulse(active);
      }, 30);
    }
  }

  function openColorPicker(card) {
    const body = document.createElement("div");
    body.className = "uno-color-picker";
    body.innerHTML = '<p class="uno-color-hint">اختر اللون الذي سيسري على الدور التالي. البطاقة البرّية تُلعب على أي لون.</p>';
    const grid = document.createElement("div");
    grid.className = "uno-color-grid";
    body.appendChild(grid);

    const dialog = BG.openDialog({
      title: "اختر لونًا",
      body,
      actions: [{ label: "إلغاء", value: "" }],
      className: "uno-dialog",
    });

    COLOR_KEYS.forEach((key) => {
      const button = BG.el("button", {
        type: "button",
        class: "uno-color-choice is-" + key,
        style: { "--cc": COLORS[key].hex },
      });
      button.innerHTML = '<span class="uno-color-dot"></span><strong>' + COLORS[key].name + "</strong>";
      button.addEventListener("click", () => dialog.close(key));
      grid.appendChild(button);
    });

    dialog.promise.then((value) => {
      if (value && COLORS[value]) playCard(card, value);
    });
  }

  function handleCard(cardId) {
    if (!state || state.over || !state.handRevealed) return;
    const card = cur().hand.find((item) => item.id === cardId);
    if (!card) return;
    if (!isPlayable(card, state.current)) {
      BG.toast(
        state.phase === "drawn"
          ? "بعد السحب يمكنك لعب البطاقة المسحوبة فقط، أو إنهاء الدور."
          : "هذه البطاقة لا تطابق اللون أو الرقم أو الرمز الحالي.",
        "warn"
      );
      if (FX) FX.sound("error");
      return;
    }
    if (card.color === "wild") {
      openColorPicker(card);
      return;
    }
    playCard(card, null);
  }

  /* ------------------------------ النهاية ------------------------------ */

  function bestColorFor(hand) {
    const counts = { red: 0, yellow: 0, green: 0, blue: 0 };
    (hand || []).forEach((card) => {
      if (counts[card.color] != null) counts[card.color] += 1;
    });
    return COLOR_KEYS.slice().sort((a, b) => counts[b] - counts[a])[0] || "red";
  }

  /** توزيع جولة جديدة وتطبيق تأثير أول بطاقة مكشوفة وفق القواعد الرسمية. */
  function newDeal(startIndex) {
    state.deck = U.shuffle(buildDeck());
    state.discard = [];
    state.players.forEach((player) => { player.hand = []; });
    for (let round = 0; round < 7; round++) {
      state.players.forEach((player) => { player.hand.push(state.deck.shift()); });
    }

    let first = null;
    let guard = state.deck.length;
    while (guard-- > 0 && state.deck.length) {
      const card = state.deck.shift();
      if (card.type === "wild4") {
        state.deck.push(card);
        continue;
      }
      first = card;
      state.discard.push(card);
      break;
    }
    if (!first) {
      first = state.deck.shift();
      state.discard.push(first);
    }

    state.dir = 1;
    state.drawnCard = null;
    state.pendingDraw = 0;
    state.challenge = null;
    state.phase = "play";
    state.current = startIndex;
    state.lastCard = first;
    let effect = "";

    if (first.color === "wild") {
      state.color = bestColorFor(state.players[startIndex].hand);
      effect = "أول بطاقة برّية؛ اختير اللون " + COLORS[state.color].name;
    } else {
      state.color = first.color;
    }

    if (first.type === "skip") {
      state.current = nextFrom(startIndex, 1);
      effect = "أول بطاقة تخطٍّ؛ خسر " + state.players[startIndex].name + " دوره";
    } else if (first.type === "reverse") {
      if (state.players.length === 2) {
        state.current = nextFrom(startIndex, 1);
        effect = "أول بطاقة عكس مع لاعبين؛ تعمل كتخطٍّ";
      } else {
        state.dir = -1;
        effect = "أول بطاقة عكس؛ بدأ اللعب بعكس عقارب الساعة";
      }
    } else if (first.type === "draw2") {
      const got = drawInto(startIndex, 2);
      state.current = nextFrom(startIndex, 1);
      effect = "أول بطاقة +2؛ سحب " + state.players[startIndex].name + " " + drawPhrase(got) + " وفقد دوره";
    } else if (first.type === "number") {
      effect = "أول بطاقة: " + cardLabel(first);
    }

    state.notice = "دور " + state.players[state.current].name + " — " + effect + ".";
    return first;
  }

  function startNextRound() {
    if (!state || state.over || state.phase !== "roundover") return;
    const previousWinner = Number.isInteger(state.winner) ? state.winner : 0;
    state.round += 1;
    state.roundOver = false;
    state.winner = null;
    state.gained = 0;
    state.roundPoints = 0;
    state.turn = 1;
    const start = (previousWinner + 1) % state.players.length;
    const first = newDeal(start);
    state.handRevealed = !BG.prefs.hideSecrets || isOnline();
    if (apiRef) {
      apiRef.log("بدأت الجولة " + state.round + " — البطاقة المكشوفة: " + U.escape(cardLabel(first)) +
        ". يبدأ " + U.escape(state.players[start].name) + ".", "accent");
    }
    if (FX) FX.sound("shuffle");
    render();
  }

  function endMatch(winnerIndex) {
    state.over = true;
    state.phase = "over";
    state.roundOver = false;
    state.winner = winnerIndex;
    state.handRevealed = false;
    const winner = state.players[winnerIndex];
    const ranking = state.players.slice().sort((a, b) => (state.scores[b.index] || 0) - (state.scores[a.index] || 0));

    if (winner) {
      state.notice = "فاز " + winner.name + " بالمباراة — وصل إلى " + state.scores[winnerIndex] + " نقطة.";
      if (apiRef) {
        apiRef.log("🏆 <strong>" + U.escape(winner.name) + "</strong> فاز بالمباراة بعد وصوله إلى " +
          state.scores[winnerIndex] + " نقطة.", "good");
        apiRef.setStatus("فاز " + winner.name);
      }
    }

    render();
    if (FX) FX.after(() => FX.win(), 140);

    if (apiRef) {
      apiRef.gameOver({
        icon: "🏆",
        title: winner ? "فاز " + winner.name + " بالمباراة!" : "انتهت المباراة",
        text: winner
          ? "وصل <strong>" + U.escape(winner.name) + "</strong> إلى هدف <strong>" +
            (unoOption("matchTo500") ? "500" : "الجولة الواحدة") + "</strong> نقطة. الترتيب النهائي حسب مجموع النقاط."
          : "لم يتبقَّ لاعب قادر على المتابعة.",
        winner: winner ? winner.name : "لا فائز",
        standings: ranking.map((player, place) => ({
          name: player.name + (player.index === winnerIndex ? " · الفائز" : ""),
          value: (state.scores[player.index] || 0) + " نقطة · المركز " + (place + 1),
        })),
      });
    }
  }

  function endGame(winnerIndex) {
    if (!state || state.over || state.roundOver) return;
    const winner = winnerIndex != null ? state.players[winnerIndex] : null;
    let points = 0;
    state.players.forEach((player) => {
      if (player.index !== winnerIndex) points += player.hand.reduce((sum, card) => sum + cardPoints(card), 0);
    });
    state.gained = points;
    state.roundPoints = points;
    state.winner = winnerIndex;
    state.handRevealed = false;
    if (winner) state.scores[winnerIndex] = (state.scores[winnerIndex] || 0) + points;

    const target = unoOption("matchTo500") ? 500 : 0;
    if (!winner || (target && state.scores[winnerIndex] < target)) {
      state.roundOver = true;
      state.phase = "roundover";
      state.current = Number.isInteger(winnerIndex) ? winnerIndex : state.current;
      state.notice = winner
        ? "فاز " + winner.name + " بالجولة (+" + points + " نقطة). مجموعه الآن " +
          state.scores[winnerIndex] + " نقطة من هدف " + target + "."
        : "انتهت الجولة دون فائز.";
      if (apiRef && winner) {
        apiRef.log("<strong>" + U.escape(winner.name) + "</strong> فاز بالجولة (+" + points +
          " نقطة). المجموع: " + state.scores[winnerIndex] + "/" + target + ".", "good");
        apiRef.setStatus("فاز " + winner.name + " بالجولة");
      }
      if (FX) FX.after(() => FX.sound("win"), 140);
      render();
      return;
    }

    endMatch(winnerIndex);
  }

  /* ------------------------------ الكمبيوتر ------------------------------ */

  function cpuColor(player) {
    const counts = { red: 0, yellow: 0, green: 0, blue: 0 };
    player.hand.forEach((card) => {
      if (counts[card.color] != null) counts[card.color] += 1;
    });
    return COLOR_KEYS.slice().sort((a, b) => counts[b] - counts[a])[0] || "red";
  }

  function cpuCardScore(card, player) {
    const next = state.players[nextIndex(1)];
    const pressure = next && next.hand.length === 1;
    let score = 0;
    if (card.type === "wild4") score += pressure ? 95 : 18;
    else if (card.type === "wild") score += pressure ? 80 : 26;
    else if (card.type === "draw2") score += pressure ? 90 : 55;
    else if (card.type === "skip") score += pressure ? 85 : 50;
    else if (card.type === "reverse") score += pressure ? 70 : 42;
    else score += 30 + (card.value || 0);
    if (state.players.length === 2 && card.type !== "number") score += 5;
    return score;
  }

  function pickCpuCard(seat, choices) {
    return AI.choose(choices, (card) => cpuCardScore(card, seat), seat.level) || choices[0];
  }

  function syncCpu() {
    if (!aiRunner) return;
    aiRunner.clear();
    if (!state || state.over) return;
    const seat = cur();
    if (!AI.isCpu(seat)) return;
    if (!AI.autoAllowed(apiRef, seat)) return;
    const wait = AI.delay(seat.level, 1.2);

    if (state.phase === "challenge") {
      aiRunner.later(() => {
        if (!state || state.over || state.phase !== "challenge") return;
        const chance = seat.level === "hard" ? 0.68 : seat.level === "easy" ? 0.22 : 0.46;
        resolveChallenge(Math.random() < chance);
      }, Math.max(520, wait));
      return;
    }

    if (state.phase === "roundover") {
      aiRunner.later(() => {
        if (!state || state.over || state.phase !== "roundover") return;
        startNextRound();
      }, Math.max(900, wait + 500));
      return;
    }

    if (state.phase === "play") {
      const choices = seat.hand.filter((card) => isPlayable(card, state.current));
      if (choices.length) {
        const card = pickCpuCard(seat, choices);
        aiRunner.later(() => {
          if (!state || state.over || state.phase !== "play") return;
          const actual = cur().hand.find((item) => item.id === card.id);
          if (actual && isPlayable(actual, state.current)) playCard(actual, cpuColor(cur()));
        }, wait);
      } else {
        aiRunner.later(() => {
          if (!state || state.over || state.phase !== "play") return;
          drawCard();
        }, wait);
      }
      return;
    }

    if (state.phase === "drawn") {
      aiRunner.later(() => {
        if (!state || state.over || state.phase !== "drawn") return;
        const drawn = cur().hand.find((item) => item.id === state.drawnCard);
        if (drawn && isPlayable(drawn, state.current)) playCard(drawn, cpuColor(cur()));
        else passTurn();
      }, wait);
    }
  }

  /* ------------------------------ العرض ------------------------------ */

  function cardHTML(card, opts) {
    const o = opts || {};
    const wild = card.color === "wild";
    const classes = ["uno-card", "is-" + card.color];
    if (o.hand) classes.push("is-hand");
    if (o.discard) classes.push("is-discard");
    if (o.drawn) classes.push("is-drawn");
    if (o.blocked) classes.push("is-blocked");
    const tag = o.hand ? "button" : "div";
    const attrs = o.hand
      ? ' type="button" data-card="' + U.escape(card.id) + '" aria-label="' + U.escape(cardLabel(card)) + '"'
      : ' aria-label="' + U.escape(cardLabel(card)) + '"';
    const pieceAttr = o.piece
      ? ' data-fx-piece="' + U.escape(o.piece) + '" data-fx-enter="' + (o.enter || "pop") + '"'
      : "";
    const face = cardFace(card);
    const corner = wild ? (card.type === "wild4" ? "+4" : "★") : face;
    return (
      "<" + tag + ' class="' + classes.join(" ") + '"' + attrs + pieceAttr + ">" +
      '<span class="uno-card-corner tl" aria-hidden="true">' + U.escape(corner) + "</span>" +
      '<span class="uno-card-face" aria-hidden="true">' + U.escape(face) + "</span>" +
      '<span class="uno-card-corner br" aria-hidden="true">' + U.escape(corner) + "</span>" +
      (wild ? '<span class="uno-card-wild-tag">' + (card.type === "wild4" ? "برّي +4" : "برّي") + "</span>" : "") +
      "</" + tag + ">"
    );
  }

  function canDrawNow() {
    return !state.over && state.phase === "play" && state.handRevealed &&
      (!isOnline() || viewerIndex() === state.current);
  }

  function tableHTML() {
    const top = topCard();
    const dirLabel = state.dir > 0 ? "مع عقارب الساعة" : "عكس عقارب الساعة";
    const dirIcon = state.dir > 0 ? "↻" : "↺";
    const seats = state.players.map((player) => {
      const active = !state.over && player.index === state.current;
      const backs = Array.from({ length: Math.min(player.hand.length, 5) }, () => "<i></i>").join("");
      return '<div class="uno-seat' + (active ? " is-active" : "") + (player.hand.length === 1 ? " is-uno" : "") + '" style="--p:' + player.color + '">' +
        '<span class="uno-seat-avatar">' + (player.index + 1) + "</span>" +
        '<span class="uno-seat-copy"><strong>' + U.escape(player.name) + "</strong><small>" + player.hand.length + " بطاقة</small></span>" +
        '<span class="uno-seat-cards" aria-hidden="true">' + backs + "</span>" +
        (player.hand.length === 1 ? '<b class="uno-seat-uno">أونو!</b>' : "") +
        "</div>";
    }).join("");
    return (
      '<div class="uno-table" style="--uc:' + COLORS[state.color].hex + '">' +
      '<div class="uno-seats">' + seats + "</div>" +
      '<div class="uno-pile uno-pile-draw">' +
      '<span class="uno-pile-label">السحب · <b>' + state.deck.length + "</b></span>" +
      '<button type="button" class="uno-card uno-card-back" data-act="draw" aria-label="اسحب بطاقة من كومة السحب"' + (canDrawNow() ? "" : " disabled") + ">" +
      '<span class="uno-back-oval" aria-hidden="true"><b>أونو</b></span>' +
      "</button>" +
      "</div>" +
      '<div class="uno-core" aria-hidden="true">' +
      '<span class="uno-core-glow"><i>' + dirIcon + "</i></span>" +
      '<span class="uno-core-color"><i class="uno-color-dot is-' + state.color + '"></i>' + U.escape(COLORS[state.color].name) + "</span>" +
      '<span class="uno-core-dir">' + dirIcon + " " + U.escape(dirLabel) + "</span>" +
      "</div>" +
      '<div class="uno-pile uno-pile-discard">' +
      '<span class="uno-pile-label">المكشوفة</span>' +
      (top ? cardHTML(top, { discard: true, piece: "uno-top-" + top.id, enter: "deal" }) : "") +
      "</div>" +
      "</div>" +
      '<div class="uno-table-meta">' +
      '<span class="uno-meta-chip">🂠 ' + state.deck.length + " في السحب</span>" +
      '<span class="uno-meta-chip">♻️ ' + Math.max(0, state.discard.length - 1) + " قابلة لإعادة الخلط</span>" +
      '<span class="uno-meta-chip">👥 ' + state.players.length + " لاعبين</span>" +
      "</div>"
    );
  }

  function playersHTML() {
    return state.players.map((player) => {
      const active = !state.over && player.index === state.current;
      const uno = player.hand.length === 1;
      return (
        '<div class="uno-player' + (active ? " active" : "") + (uno ? " is-uno" : "") + '" style="--p:' + player.color + '">' +
        BG.playerProfile.playerHTML(player, "uno-player-avatar") +
        '<div class="uno-player-copy"><strong>' + U.escape(player.name) + "</strong>" +
        "<small>" + player.hand.length + " بطاقة" + (unoOption("matchTo500") ? " · " + (state.scores[player.index] || 0) + " نقطة" : "") + "</small></div>" +
        (uno ? '<span class="uno-badge">أونو!</span>' : "") +
        "</div>"
      );
    }).join("");
  }

  function turnHTML() {
    const player = cur();
    const drawn = state.drawnCard && canSeeActiveHand() ? cur().hand.find((card) => card.id === state.drawnCard) : null;
    const drawnPlayable = drawn ? matches(drawn) : false;
    const phaseLabel = state.over
      ? "المباراة منتهية"
      : state.phase === "roundover"
        ? "نهاية الجولة " + state.round
        : state.phase === "challenge"
          ? "تحدي +4"
          : state.phase === "drawn"
            ? "بعد السحب"
            : "اللعب";
    return (
      '<div class="uno-panel uno-turn">' +
      '<span class="uno-kicker">الدور ' + state.turn + " · جولة " + state.round + " · " + phaseLabel + "</span>" +
      "<strong>" + U.escape(state.over ? "انتهت المباراة" : state.phase === "roundover" ? "فاز " + (state.players[state.winner] || player).name + " بالجولة" : player.name) + "</strong>" +
      "<small>" + (state.over || state.phase === "roundover"
        ? "المجموع التراكمي: " + state.players.map((item) => item.name + " " + (state.scores[item.index] || 0)).join(" · ")
        : state.phase === "challenge"
          ? "على " + player.name + " اختيار التحدي أو سحب أربع بطاقات"
          : player.hand.length + " بطاقة · " + (player.hand.length === 1 ? "على وشك الفوز" : "بانتظار بطاقة مناسبة")) + "</small>" +
      '<div class="uno-turn-chips">' +
      '<span class="uno-color-chip is-' + state.color + '"><i class="uno-color-dot"></i>' + U.escape(COLORS[state.color].name) + "</span>" +
      '<span class="uno-dir-chip">' + (state.dir > 0 ? "↻" : "↺") + " " + (state.dir > 0 ? "مع عقارب الساعة" : "عكس عقارب الساعة") + "</span>" +
      "</div>" +
      (state.phase === "drawn" && !state.over
        ? canSeeActiveHand()
          ? '<div class="uno-drawn-hint ' + (drawnPlayable ? "ok" : "wait") + '">' +
            (drawn ? "البطاقة المسحوبة: " : "") +
            (drawn ? "<strong>" + U.escape(cardLabel(drawn)) + "</strong>" : "لا توجد بطاقة مسحوبة") +
            "<small>" + (drawnPlayable ? "قابلة للعب — انقرها في يدك أو أنهِ الدور." : "غير مطابقة — أنهِ الدور.") + "</small></div>"
          : '<div class="uno-drawn-hint wait"><strong>اللاعب يختار من يده</strong><small>أوراقه مخفية عن المشاهدين.</small></div>'
        : "") +
      (state.phase === "challenge" && !state.over
        ? '<div class="uno-challenge-box"><strong>🃏 بطاقة +4 على الطاولة</strong>' +
          "<small>التحدي يكشف إن كان صاحب البطاقة يملك لونًا مطابقًا. النجاح: يسحب هو ٤ بطاقات. الفشل: تسحب أنت ٦ بطاقات وتفقد دورك.</small></div>"
        : "") +
      "</div>"
    );
  }

  function actionsHTML() {
    const canAct = !isOnline() || viewerIndex() === state.current;
    const canDraw = canDrawNow();
    const canPass = !state.over && state.phase === "drawn";
    const canChallenge = !state.over && state.phase === "challenge" && canAct;
    const canNext = !state.over && state.phase === "roundover" && canAct;
    const hint = state.over
      ? "انتهت المباراة. ابدأ لعبة جديدة من زر «لعبة جديدة»."
      : state.phase === "roundover"
        ? (canAct ? "اضغط «الجولة التالية» لتوزيع بطاقات جديدة." : "بانتظار الفائز ليبدأ الجولة التالية.")
        : state.phase === "challenge"
          ? (canAct ? "قرّر الآن: تحدَّ البطاقة أو اقبل سحب أربع بطاقات." : "بانتظار قرار اللاعب المستهدف ببطاقة +4.")
          : !state.handRevealed
            ? "أظهر يدك أولًا من لوحة «أوراقك» لتتمكن من اللعب أو السحب."
            : state.pendingDraw > 0
              ? "عليك سحب " + state.pendingDraw + " بطاقات. إن ملكت +2 (أو +4) مماثلة كدّسها وأمرر العقوبة للتالي، وإلا اسحب الكل."
              : state.phase === "drawn"
              ? "بعد السحب يمكنك لعب البطاقة المسحوبة فقط، أو إنهاء الدور."
              : "طابق اللون الحالي أو الرقم أو رمز البطاقة. إن لم تملك بطاقة مناسبة فاسحب واحدة.";
    return (
      '<div class="uno-panel uno-actions">' +
      '<span class="uno-kicker">أوامر الدور</span>' +
      (canChallenge
        ? '<button type="button" class="bg-btn primary" data-act="challenge"><span>🎯 تحدَّ بطاقة +4</span></button>' +
          '<button type="button" class="bg-btn" data-act="accept4"><span>🂠 اقبل واسحب ٤</span></button>'
        : canNext
          ? '<button type="button" class="bg-btn primary" data-act="next-round"><span>🔄 الجولة التالية</span></button>'
          : '<button type="button" class="bg-btn primary" data-act="draw"' + (canDraw ? "" : " disabled") + '><span>' + (state.pendingDraw > 0 ? "🂠 اسحب " + state.pendingDraw + " بطاقات" : "🂠 اسحب بطاقة") + '</span></button>' +
            '<button type="button" class="bg-btn" data-act="pass"' + (canPass ? "" : " disabled") + '><span>⏭ أنهِ الدور</span></button>') +
      '<p class="uno-hint">' + U.escape(hint) + "</p>" +
      "</div>"
    );
  }

  function handHTML() {
    const player = viewerPlayer();
    if (!player) {
      return '<p class="uno-empty">أنت مشاهد — لا تُعرض أوراق اللاعبين السرّية على هذا الجهاز.</p>';
    }
    if (!player.hand.length) {
      return '<p class="uno-empty">لا بطاقات في يدك — انتهت الجولة.</p>';
    }
    const cards = sortHand(player.hand);
    const playable = cards.filter((card) => isPlayable(card, player.index)).length;
    return (
      '<div class="uno-hand-meta"><span>' + cards.length + " بطاقة</span><b>" + playable + " قابلة للعب</b>" +
      (state.drawnCard ? '<span class="uno-hand-drawn">المسحوبة مميزة بإطار</span>' : "") + "</div>" +
      '<div class="uno-hand">' +
      cards.map((card) => cardHTML(card, {
        piece: "uno-hand-" + card.id,
        enter: "deal",
        hand: true,
        blocked: !isPlayable(card, player.index),
        drawn: card.id === state.drawnCard,
      })).join("") +
      "</div>" +
      '<p class="uno-hand-hint">البطاقات الباهتة غير مطابقة. البرّية تُلعب دائمًا وتغيّر اللون.</p>'
    );
  }

  function sideHTML() {
    return (
      turnHTML() +
      actionsHTML() +
      '<div class="uno-notice">' + U.escape(state.notice) + "</div>" +
      '<div class="uno-panel uno-players"><span class="uno-kicker">اللاعبون</span>' + playersHTML() + "</div>" +
      '<div class="uno-panel uno-legend">' +
      '<span class="uno-kicker">كيف تلعب</span>' +
      '<div class="uno-legend-row"><b>🎨</b><span>طابق اللون أو الرقم أو رمز البطاقة. البرّية تُلعب على أي بطاقة.</span></div>' +
      '<div class="uno-legend-row"><b>⊘</b><span>تخطٍّ يمنع اللاعب التالي، وعكس يقلب اتجاه اللعب.</span></div>' +
      '<div class="uno-legend-row"><b>+2</b><span>البطاقات العقابية تُنقل الدور بعد أن يسحب الخصم بطاقاته.</span></div>' +
      '<div class="uno-legend-row"><b>🗣</b><span>عند بقاء بطاقة واحدة يُعلن «أونو!» تلقائيًا. أول من يفرغ يفوز.</span></div>' +
      "</div>"
    );
  }

  /* ------------------------------ حركة الأوراق ------------------------------ */

  /* لقطة من الحالة عند آخر رسم، ونقارنها بالحالة الجديدة: إن تغيّرت الورقة العليا طارت ورقة من مصدرها،
     وإن زاد عدد أوراق لاعب طارت أوراق من كومة السحب. هذا يعمل للاعب والكمبيوتر والأونلاين
     دون أن يؤخّر شيئًا من منطق اللعبة. */
  let lastSnap = null;

  function fxSnapshot() {
    const viewer = viewerPlayer();
    const top = topCard();
    return {
      round: state.round,
      top: top ? top.id : null,
      counts: state.players.map((player) => player.hand.length),
      mine: viewer ? viewer.hand.map((card) => card.id) : [],
      mineIndex: viewer ? viewer.index : -1,
    };
  }

  /* تُستدعى قبل استبدال الـ DOM القديم حتى يمكن التقاط ورقة اللاعب من يده */
  function planFlights(snap) {
    const jobs = [];
    if (!FX || !FX.cardFlight || !FX.motionEnabled() || !rootRef) return jobs;
    const prev = lastSnap;
    if (!prev || prev.round !== snap.round) {
      if (state.turn <= 1) jobs.push({ kind: "deal" });
      return jobs;
    }
    let who = -1;
    if (snap.top && snap.top !== prev.top) {
      snap.counts.forEach((count, i) => { if (count < prev.counts[i]) who = i; });
      if (who >= 0) {
        const fromHand = who === snap.mineIndex && prev.mineIndex === who
          ? rootRef.querySelector('[data-card="' + snap.top + '"]')
          : null;
        const seat = rootRef.querySelectorAll(".uno-seat")[who];
        if (fromHand) jobs.push({ kind: "play", flight: FX.cardFlight(fromHand), face: "source" });
        else if (seat) jobs.push({ kind: "play", flight: FX.cardFlight(seat, { center: true }), face: "target" });
      }
    }
    snap.counts.forEach((count, i) => {
      const gained = count - prev.counts[i] + (i === who ? 1 : 0);
      if (gained <= 0) return;
      const ids = i === snap.mineIndex && prev.mineIndex === i
        ? snap.mine.filter((id) => prev.mine.indexOf(id) < 0)
        : [];
      jobs.push({ kind: "draw", player: i, count: Math.min(gained, 5), ids });
    });
    return jobs;
  }

  /* تُستدعى بعد بناء الـ DOM الجديد لتطير الأوراق إلى مواضعها النهائية */
  function runFlights(jobs) {
    if (!jobs.length || !rootRef) return;
    const deck = rootRef.querySelector(".uno-card-back");
    const seats = rootRef.querySelectorAll(".uno-seat");
    jobs.forEach((job) => {
      if (job.kind === "deal") {
        if (!deck || !seats.length) return;
        const rounds = Math.min(3, Math.max(1, Math.ceil(12 / seats.length)));
        for (let r = 0; r < rounds; r++) {
          Array.prototype.forEach.call(seats, (seat, i) => {
            FX.cardFlight(deck).land(seat, { mode: "point", delay: (r * seats.length + i) * 75, duration: 420 });
          });
        }
      } else if (job.kind === "play") {
        const discard = rootRef.querySelector(".uno-card.is-discard");
        if (discard) job.flight.land(discard, { face: job.face, onDone: () => { if (FX.pop) FX.pop(discard); } });
      } else if (job.kind === "draw" && deck) {
        for (let k = 0; k < job.count; k++) {
          const own = job.ids[k] ? rootRef.querySelector('[data-card="' + job.ids[k] + '"]') : null;
          const target = own || seats[job.player];
          if (!target) continue;
          FX.cardFlight(deck).land(target, own ? { delay: k * 110 } : { mode: "point", delay: k * 110 });
        }
      }
    });
  }

  /* زر كبير في منتصف الطاولة عند الحاجة: اسحب إن لم تملك ورقة تُلعب، أنهِ الدور إن سحبت ولم تنفع،
     والجولة التالية عند انتهاء الجولة. يضغط الزر الأصلي فتبقى كل القواعد كما هي. */
  function syncCenterPad() {
    if (!FX || !FX.centerPad || !rootRef || !state) return;
    const table = rootRef.querySelector(".uno-table");
    if (!table) return;
    let spec = null;
    const player = cur();
    const mine = !state.over && player && !AI.isCpu(player) && (!isOnline() || viewerIndex() === state.current);
    if (mine) {
      const hasPlay = player.hand.some((card) => isPlayable(card, player.index));
      if (state.phase === "roundover") spec = { key: "next", act: "next-round", icon: "🔄", label: "الجولة التالية" };
      else if (state.phase === "play" && state.handRevealed && !hasPlay) {
        spec = { key: "draw" + state.pendingDraw, act: "draw", icon: "🂠", label: state.pendingDraw > 0 ? "اسحب " + state.pendingDraw + " بطاقات" : "اسحب ورقة" };
      } else if (state.phase === "drawn" && !hasPlay) spec = { key: "pass", act: "pass", icon: "⏭", label: "أنهِ الدور" };
    }
    FX.centerPad(table, spec && {
      key: spec.key,
      icon: spec.icon,
      label: spec.label,
      onClick: () => {
        const btn = rootRef && rootRef.querySelector('[data-act="' + spec.act + '"]:not(:disabled)');
        if (btn) btn.click();
      },
    });
  }

  function render() {
    if (!rootRef || !state) return;
    const wrap = document.createElement("div");
    wrap.className = "uno-layout";

    const main = document.createElement("div");
    main.className = "uno-main";

    const board = document.createElement("div");
    board.className = "uno-board-wrap";
    board.innerHTML =
      '<div class="board-head">' +
      '<span class="board-head-icon"><svg class="ic" aria-hidden="true"><use href="#g-uno"/></svg></span>' +
      '<div class="board-head-copy"><span class="board-head-kicker">طاولة سريعة</span><strong>١٠٨ بطاقات · ٤ ألوان</strong></div>' +
      '<span class="board-head-hint">طابق اللون أو الرقم أو الرمز · البرّية تغيّر اللون · أونو عند البطاقة الأخيرة</span>' +
      "</div>" + tableHTML();
    main.appendChild(board);

    const player = viewerPlayer() || cur();
    if (viewerPlayer()) {
      const secret = BG.secretPanel({
        title: "🃏 أوراق " + player.name,
        owner: player.name,
        hint: "يدك سرّية. أظهرها فقط في دورك، ثم أخفها قبل تمرير الجهاز.",
        open: state.handRevealed,
        autoKey: isOnline() ? "uno:" + viewerIndex() + ":" + state.current : "",
        onToggle(visible) {
          state.handRevealed = visible;
          render();
        },
        render() {
          return handHTML();
        },
      });
      main.appendChild(secret.el);
    } else {
      const watch = document.createElement("div");
      watch.className = "uno-panel uno-watch";
      watch.innerHTML =
        '<span class="uno-kicker">👁 وضع المشاهدة</span>' +
        '<p class="uno-hand-hint">تتابع الطاولة مباشرة. تبقى أوراق كل اللاعبين مخفية، ويُفتح مقعدك عند دورك.</p>';
      main.appendChild(watch);
    }

    const side = document.createElement("aside");
    side.className = "uno-side";
    side.innerHTML = sideHTML();

    wrap.appendChild(main);
    wrap.appendChild(side);
    const snap = fxSnapshot();
    const jobs = planFlights(snap);
    rootRef.innerHTML = "";
    rootRef.appendChild(wrap);
    lastSnap = snap;
    runFlights(jobs);
    syncCenterPad();
    syncCpu();
  }

  /* ------------------------------ الأحداث ------------------------------ */

  function handleClick(event) {
    if (state && !state.over && AI.isCpu(cur())) return;
    if (isOnline() && viewerIndex() !== state.current) return;
    const card = event.target.closest("[data-card]");
    if (card) {
      handleCard(card.getAttribute("data-card"));
      return;
    }
    const action = event.target.closest("[data-act]");
    if (!action) return;
    const act = action.getAttribute("data-act");
    if (act === "draw") drawCard();
    else if (act === "pass") passTurn();
    else if (act === "challenge") resolveChallenge(true);
    else if (act === "accept4") resolveChallenge(false);
    else if (act === "next-round") startNextRound();
  }

  /* ------------------------------ التسجيل ------------------------------ */

  const game = {
    id: "uno",
    name: "أونو",
    en: "UNO",
    icon: "🃏",
    accent: "#e94f64",
    cardClass: "card-uno",
    tagline: "طابق الألوان والأرقام، وألقِ البطاقات العقابية، وكن أول من يفرغ يده.",
    players: "2–6",
    duration: "15–30 دقيقة",
    complexity: "سهلة",
    minPlayers: 2,
    maxPlayers: 6,
    defaultPlayers: 4,

    options: {
      hint: "خيارات قوانين إضافية. يمكن تخصيصها قبل بدء المباراة.",
      defaults: { drawUntilPlayable: false, stackDraw: false, challengeWild4: true, matchTo500: true },
      fields: [
        { key: "matchTo500", label: "مباراة كاملة حتى 500 نقطة", type: "toggle", hint: "جولات متتالية حتى يبلغ أحد اللاعبين 500 نقطة، كما في القواعد الرسمية." },
        { key: "challengeWild4", label: "السماح بتحدي بطاقة +4", type: "toggle", hint: "المستهدف يقرر التحدي أو القبول؛ النجاح يعاقب صاحب البطاقة." },
        { key: "drawUntilPlayable", label: "سحب حتى الحصول على بطاقة قابلة للعب", type: "toggle", hint: "قاعدة منزلية: السحب يستمر حتى تظهر بطاقة قابلة للعب." },
        { key: "stackDraw", label: "تكديس +2/+4", type: "toggle", hint: "قاعدة منزلية: السماح بتكديس +2 على +2 و+4 على +4." },
      ],
      summary(options) {
        const parts = [];
        if (options.matchTo500 !== false) parts.push("حتى 500 نقطة");
        if (options.challengeWild4 !== false) parts.push("تحدي +4");
        if (options.drawUntilPlayable) parts.push("سحب متكرر");
        if (options.stackDraw) parts.push("تكديس +2/+4");
        return parts.join(", ") || "القواعد القياسية";
      },
    },
    rules: {
      goal: "تخلّص من جميع بطاقاتك قبل الجميع. في كل دور العب بطاقة تطابق لون البطاقة المكشوفة أو رقمها أو رمزها، واستخدم البطاقات الخاصة لتخطّي الخصوم أو عكس اتجاه اللعب أو إجبارهم على السحب. أول لاعب تفرغ يده يفوز بالجولة.",
      facts: [["البطاقات", "١٠٨ بطاقات"], ["الألوان", "٤ ألوان + برّي"], ["اليد", "٧ بطاقات"], ["اللاعبون", "٢–٦"]],
      components: [
        "١٠٨ بطاقات: لكل لون بطاقة صفر واحدة، وبطاقتان من كل رقم من ١ إلى ٩، وبطاقتان تخطٍّ، وبطاقتان عكس، وبطاقتان +2.",
        "٤ بطاقات برّية، و٤ بطاقات برّية +4.",
        "أربعة ألوان: أحمر، أصفر، أخضر، أزرق، إضافة إلى البطاقات البرّية متعددة الألوان.",
        "كومة سحب وكومة بطاقات مكشوفة، ويد سرّية لكل لاعب.",
      ],
      setup: [
        "تُخلط البطاقات الـ108 جيدًا وتُوزع ٧ بطاقات لكل لاعب، وتبقى البطاقات الأخرى في كومة السحب.",
        "تُكشف البطاقة العليا لتكون أول بطاقة مكشوفة. تُطبَّق بطاقات الحركة في البداية وفق القواعد الرسمية: +2 يسحبها اللاعب الأول ويُتخطّى، والتخطي يتخطّاه، والعكس يقلب الاتجاه، والبرّية يختار لها اللاعب الأول لونًا. بطاقة +4 الأولى تعود إلى الكومة وتُسحب بدلها بطاقة أخرى.",
        "يبدأ اللاعب الأول وفق ترتيب اللاعبين، ويكون اتجاه اللعب في البداية مع عقارب الساعة.",
        "لا يرى أي لاعب بطاقات الآخرين. كل لاعب يظهر يده فقط عند دوره ثم يخفيها.",
      ],
      steps: [
        "<strong>اللعب:</strong> في دورك العب بطاقة واحدة تطابق اللون الحالي، أو تحمل الرقم نفسه، أو تحمل الرمز نفسه، أو بطاقة برّية. بعد لعبها تصبح هي البطاقة المكشوفة الجديدة، ويصبح لونها هو اللون الحالي، ثم ينتقل الدور.",
        "<strong>البطاقات الرقمية:</strong> من ٠ إلى ٩. يمكن لعب الرقم نفسه بلون مختلف ما دام مطابقًا للرقم المكشوف، أو أي رقم من اللون الحالي.",
        "<strong>تخطٍّ (⊘):</strong> يخسر اللاعب التالي دوره كاملًا. مع لاعبين اثنين يعود الدور إليك مباشرة.",
        "<strong>عكس (⇄):</strong> يقلب اتجاه اللعب. مع لاعبين اثنين يعمل كتخطٍّ، فيلعب صاحب البطاقة مرة أخرى.",
        "<strong>+2:</strong> يسحب اللاعب التالي بطاقتين ويخسر دوره. لا تُراكم بطاقات +2 فوق بعضها في القواعد الرسمية (التكديس قاعدة منزلية اختيارية).",
        "<strong>برّية (★):</strong> تُلعب على أي بطاقة، ويختار لاعبها اللون الجديد من الألوان الأربعة. لا يمكن ردّها ببطاقة عادية.",
        "<strong>برّية +4:</strong> تُلعب على أي بطاقة، ويختار لاعبها اللون الجديد. يحق للاعب التالي أن يتحدى: إن كان صاحب البطاقة يملك لونًا مطابقًا للون السابق يسحب هو ٤ بطاقات، وإن فشل التحدي يسحب المتحدّي ٦ بطاقات (٤ + عقوبة ٢) ويخسر دوره. القبول يعني سحب ٤ بطاقات فقط وخسارة الدور.",
        "<strong>السحب:</strong> إن لم تملك بطاقة مطابقة، اسحب بطاقة واحدة. إن كانت قابلة للعب يمكنك لعبها فورًا، وإلا فأنهِ دورك. لا يُسمح بسحب أكثر من بطاقة في الدور نفسه.",
        "<strong>أونو:</strong> عند بقاء بطاقة واحدة في يدك يجب أن تعلن «أونو!». في النسخة الرقمية يُعلن ذلك تلقائيًا ويظهر تنبيه للجميع.",
        "<strong>نفاد كومة السحب:</strong> تُخلط البطاقات المكشوفة ما عدا البطاقة العليا لتشكيل كومة سحب جديدة، ثم يستمر اللعب.",
      ],
      winning: "يفوز أول لاعب يتخلّص من كل بطاقاته في الجولة. تُحسب نقاط الجولة للفائز من أيدي الخصوم: البطاقات الرقمية بقيمتها، وبطاقات تخطٍّ وعكس و+2 بعشرين نقطة لكل بطاقة، والبرّية والبرّية +4 بخمسين نقطة. تُلعب جولات متتالية حتى يبلغ أحد اللاعبين 500 نقطة (أو حتى نهاية الجولة الواحدة إذا عُطّل الخيار).",
      notes: [
        "الهدف الرسمي 500 نقطة عبر جولات متتالية؛ الفائز بالجولة يبدأ الجولة التالية من الجهة التالية له.",
        "لا تُراكم بطاقات +2 أو +4 افتراضيًا: كل بطاقة عقابية تُطبّق على اللاعب التالي فقط. التكديس قاعدة منزلية اختيارية.",
        "بطاقة +4 قابلة للتحدي افتراضيًا: يتحقق التحدي من وجود لون مطابق في يد صاحب البطاقة وقت لعبها.",
        "أول بطاقة مكشوفة تُطبَّق قواعدها الرسمية، بما فيها +2 والتخطي والعكس والبرّية، وتُعاد +4 إلى الكومة.",
        "إعلان «أونو» تلقائي عند بقاء بطاقة واحدة؛ لا توجد عقوبة نسيان في اللعب المحلي.",
        "يد اللاعب الحالي مخفية حتى يضغط «إظهار»، وتُخفى تلقائيًا عند انتقال الدور.",
      ],
    },

    create(root, api) {
      rootRef = root;
      apiRef = api;
      aiRunner = AI.runner();

      const players = api.players.map((player, index) => ({
        index,
        name: player.name,
        type: player.type === "cpu" ? "cpu" : "human",
        level: AI.level(player.level),
        isCpu: AI.isCpu(player),
        color: player.profileColor || PCOLORS[index % PCOLORS.length],
        hand: [],
      }));

      state = {
        players,
        deck: [],
        discard: [],
        current: 0,
        dir: 1,
        turn: 1,
        round: 1,
        roundOver: false,
        roundPoints: 0,
        scores: players.map(() => 0),
        color: "red",
        phase: "play",
        drawnCard: null,
        handRevealed: !BG.prefs.hideSecrets || isOnline(),
        pendingDraw: 0,
        challenge: null,
        lastCard: null,
        notice: "",
        over: false,
        winner: null,
        gained: 0,
      };

      lastSnap = null;
      const firstCard = newDeal(0);
      state.notice = "دور " + players[state.current].name + " — أظهر يدك ثم العب بطاقة مطابقة أو اسحب بطاقة.";
      apiRef.log(
        "بدأت أونو — " + players.length + " لاعبين، ٧ بطاقات لكل لاعب. البطاقة المكشوفة: " + U.escape(cardLabel(firstCard || topCard())) + ".",
        "accent"
      );
      if (FX) FX.sound("shuffle");
      render();

      if (new URLSearchParams(location.search).has("bgdebug")) {
        window.__bgDebug = {
          get state() { return state; },
          get players() { return state.players; },
          render, playCard, drawCard, passTurn, endGame, startNextRound, resolveChallenge, newDeal, setTurnNotice,
          topCard, buildDeck, cardLabel, cardPoints, matches, sortHand,
          isPlayable: (cardId) => {
            const card = cur().hand.find((item) => item.id === cardId);
            return card ? isPlayable(card, state.current) : false;
          },
          handOf: (index) => state.players[index].hand,
          COLORS, COLOR_KEYS,
        };
      }

      rootRef.addEventListener("click", handleClick);
      return {
        netSnapshot() {
          return state ? BG.netCodec.encode(state) : null;
        },
        netLoad(data) {
          if (!data) return;
          BG.closeDialogs();
          state = BG.netCodec.decode(data);
          state.handRevealed = !BG.prefs.hideSecrets || isOnline();
          state.pendingDraw = Number(state.pendingDraw) || 0;
          state.challenge = state.challenge || null;
          state.round = state.round || 1;
          state.roundOver = !!state.roundOver;
          state.players.forEach((player) => {
            player.hand = Array.isArray(player.hand) ? player.hand : [];
          });
          state.scores = Array.isArray(state.scores) ? state.scores : state.players.map(() => 0);
          state.deck = Array.isArray(state.deck) ? state.deck : [];
          state.discard = Array.isArray(state.discard) ? state.discard : [];
          render();
        },
        netSeat() {
          return state ? state.current : -1;
        },
        netOver() {
          return !!(state && state.over);
        },
        netResume() {
          if (!state) return;
          state.handRevealed = !BG.prefs.hideSecrets || isOnline();
          render();
        },
        destroy() {
          if (FX && FX.cancelFlights) FX.cancelFlights();
          lastSnap = null;
          if (aiRunner) aiRunner.clear();
          aiRunner = null;
          if (rootRef) rootRef.removeEventListener("click", handleClick);
          rootRef = null;
          apiRef = null;
          state = null;
        },
      };
    },
  };

  BG.register(game);
})();
